<form action="<?=$_SERVER['PHP_SELF'];?>" method="POST">
    Amount <input type="text" name="itemamount">
    <input type="submit" value="Generate">
</form>

<?php
  
    isset( $_POST['itemamount'] ) ? $itemamount = $_POST['itemamount'] : $itemamount = "";
    $request_headers = array(
      "Cache-Control: no-cache",
    );
    
    if( !empty( $itemamount ) ) {
      $token = 'p7rKwi7NK/JfQG6AX6el3fliHoNfaHILcYAPerzL4wKrUlRkx5/bXvU679swX/MTyNeZ8Q5+IbqPuj9RC3Linkmd5f6XHvKOUvT0aT75YkPWPEJ0781jgvFsLeuJgiC48oF6N8fbAiMF1ehYkm/xJDmH5+gRUSeLl7Nu/Huah7nzaTgo';
      $tokenKey = rawurlencode($token);      
      $referenceNo = time();
      $field = 'token='.$tokenKey.'&referenceNo='.$referenceNo.'&amount='.$itemamount.'';
      $url = "https://api.globalprimepay.com/v3/wechat/text";

      // curl api grcode
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $field);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLINFO_HEADER_OUT, true);
      curl_setopt($ch, CURLOPT_ENCODING, "");
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
      curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);
      $output = curl_exec($ch);
      curl_close($ch);
	  
	  echo "<pre>";
	  print_r($output);
	  die;

      // encode output from api 
      $body = 'data:image/png;base64,' . base64_encode($output) . '';
      
      // output img qrcode by html
      echo '<div class="qrcode_display" id="gbprimepay-qrcode-waiting-payment" style="display:block;">';
      echo '<img src="' . $body . '"  style="padding:0px 0px 120px 0px;windth:100%;" class="aligncenter size-full" />';
      echo '</div>';
      
    }
?>