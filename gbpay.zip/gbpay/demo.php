<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);	
	
$secretKey     = "Sj8b2dJI7hH7KGcvs5blaV0e7TQl2a0T";
$amount        = "1.00";
$referenceNo   = time();
$responseUrl   = 'https://resalebook.in/gbpay/response.php';
$backgroundUrl = 'https://resalebook.in/gbpay/background.php';
$checkSUMData  = $amount.$referenceNo.$responseUrl.$backgroundUrl;
$checkSUM      = hash_hmac('sha256', $checkSUMData,$secretKey);  

$data['publicKey']      = 'OkKm9dIyxe5Kl3P557wh7q9xdYznJRa6';	
$data['checksum']       = $checkSUM;	
$data['amount']         = $amount;	
$data['referenceNo']    = $referenceNo;
$data['payType']        = 'F';	
$data['cardUse']        = 'Y';	
$data['billUse']        = 'Y';	
$data['qrUse']          = 'Y';	
$data['expire']         = '7';		
$data['deliveryMethod'] = '00';	
$data['multipleUse'] = 'N';	
$data['responseUrl'] = $responseUrl;	
$data['backgroundUrl'] = $backgroundUrl;
$data['wechatUse'] = 'Y';	
$payload = json_encode($data);

$url = 'https://api.globalprimepay.com/gbp/gateway/v2/link';
$request_headers = array(
  "Content-Type: application/json",
);
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLINFO_HEADER_OUT, true);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch, CURLOPT_TIMEOUT, 120);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);      
$body = curl_exec($ch);
$json = json_decode($body, true);
if($json['resultCode'] == 00){
	
	header("Location:".$json['gbLinkUrl']);
}
?>