<?php

echo "<pre>";
print_r($_POST);
die;
header("Location: https://resalebook.in/gbpay/success.php", true, 301);

?>