<?php
$tokenUrl = 'https://api.globalprimepay.com/unified/authToken/create';	

// The data you want to send as JSON
$data = array(
    'secretKey' => 'Sj8b2dJI7hH7KGcvs5blaV0e7TQl2a0T',
    'publicKey' => 'OkKm9dIyxe5Kl3P557wh7q9xdYznJRa6',
);
$json_data = json_encode($data);

// Initialize cURL session
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, $tokenUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);          // Return the result as a string
curl_setopt($ch, CURLOPT_POST, 1);                    // Send via POST method
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);     // Set POST data
curl_setopt($ch, CURLOPT_HTTPHEADER, array(           // Set content type to JSON
    'Content-Type: application/json',
    'Content-Length: ' . strlen($json_data)
));

// Execute the cURL session and store the result in $response
$response = curl_exec($ch);

// Check for cURL errors
if (curl_errno($ch)) {
    echo 'cURL error: ' . curl_error($ch);
} else {
    
	$data = json_decode($response);
	$token = $data->authToken;

	$curl = curl_init();
	curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://api.globalprimepay.com/unified/transaction',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>'{
			"apiType": "PC",
			"createPaymentTransactionRequest" : {
				"referenceNo" : '.time().', 
				"paymentType" : "Q", 
				"amount" :10.00, 
				"responseUrl" : "https://resalebook.in/gbpay/response.php", 
				"backgroundUrl" : "https://resalebook.in/gbpay/background.php", 
				"detail" : "Test QR Cash BackgroundURL", 
				"customerName" : "Ryu Test", 
				"customerEmail" : "test@mail.com", 
				"customerTelephone" : "0600000000", 
				"customerAddress" : "420 WT", 
				"merchantDefined1" : "Test11", 
				"merchantDefined2" : "Test22", 
				"merchantDefined3" : "Test33", 
				"merchantDefined4" : "Test44", 
				"merchantDefined5" : "Test55"
			}
		}',
		  CURLOPT_HTTPHEADER => array(
			'Authorization:'.$token,   //Authorization key get from /unified/authToken/create 
			'Content-Type: application/json',
		  ),
	));

	$response = curl_exec($curl);
	$json = json_decode($response, true);
	header("Location:".$json['redirectUrl']);
	curl_close($curl);
}

// Close the cURL session
curl_close($ch);	
?>

<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript">
	/*
    var intervals;
    $(document).ready(function(){
        var interval = setInterval(function () { start() }, 10000);
    });
    function start()
    {
        startInsert();
        intervals = setInterval(startInsert, 10000);
    }

    function startInsert() {
        $.ajax({
            url: "https://resalebook.in/gbpay/background.php",   // url check status txn  if success href to complete
            cache: false,
            type: 'POST',
            success: function (result) {
                 window.location.href = "https://resalebook.in/gbpay/success.php";
                }
        });
    }
	*/
            
</script>