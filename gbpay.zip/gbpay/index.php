<form class="row g-3"action="<?php $_SERVER['PHP_SELF']?>" method="post">              
  <div class="col-md-6">
      <label for="cardNumber" class="form-label">CardNumber</label>
      <input type="text" class="form-control" id="cardNumber" name="cardNumber" value=''/>
  </div>
  <div class="col-md-6">
      <label for="expirationMonth" class="form-label">ExpirationMonth</label>
      <input type="text" class="form-control" id="expirationMonth" name="expirationMonth" value=''/>
  </div>
  <div class="col-md-6">
      <label for="expirationYear" class="form-label">ExpirationYear</label>
      <input type="text" class="form-control" id="expirationYear" name="expirationYear" value=''/>
  </div>
  <div class="col-md-6">
      <label for="securityCode" class="form-label">SecurityCode</label>
      <input type="text" class="form-control" id="securityCode" name="securityCode" value=''/>
  </div>
  <button type="submit" class="btn btn-primary">Gen Token</button>
</form>

<?php  
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      $data = array(
          "rememberCard" => false,
          "card" => array (
              "number" => $_POST['cardNumber'],
              "expirationMonth" => $_POST['expirationMonth'],
              "expirationYear" => $_POST['expirationYear'],
              "securityCode" => $_POST['securityCode'],
              "name" => "Card Test UAT (Server Test)"
          )
      );
      $payload = json_encode($data);
      $url = 'https://api.globalprimepay.com/v2/tokens';  // Test URL: https://api.globalprimepay.com/v2/tokens , Production URL: https://api.gbprimepay.com/v2/tokens
      $configkey = "OkKm9dIyxe5Kl3P557wh7q9xdYznJRa6";  
      $key = base64_encode("{$configkey}".":");  
      $request_headers = array(
          "Accept: application/json",
          "Authorization: Basic {$key}",
          "Cache-Control: no-cache",
          "Content-Type: application/json",
      );
      $ch = curl_init($url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLINFO_HEADER_OUT, true);
      curl_setopt($ch, CURLOPT_ENCODING, "");
      curl_setopt($ch, CURLOPT_TIMEOUT, 120);
      curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
      curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);      
      $body = curl_exec($ch);
      $json = json_decode($body, true);
      curl_close($ch);
	  echo "<pre>";
	  print_r($json);
      if($json['resultCode'] != 00){
	  
		echo $json['resultMessage'];
	  }
	  else{
	  
		echo $json['card']['token'];
		$token = $json['card']['token'];
		$data = array(
			'amount' => 100,
			'referenceNo' => '20171128001',
			'detail' => 't-shirt',
			'customerName' => 'John',
			'customerEmail' => 'example@gbprimepay.com',
			'merchantDefined1' => 'Promotion',
			'card' => array(
			  'token' => $token, //get card_token by Token API
			),
			'otp' => 'Y',
			'backgroundUrl' => 'background.php',
			'responseUrl' => 'response.php'
		);
		
		$payload = json_encode($data);
		$url = 'https://api.globalprimepay.com/v2/tokens/charge';
		$configkey = "Sj8b2dJI7hH7KGcvs5blaV0e7TQl2a0T";  
		$key = base64_encode("{$configkey}".":");
		$request_headers = array(
			"Accept: application/json",
			"Authorization: Basic {$key}",
			"Cache-Control: no-cache",
			"Content-Type: application/json",
		);
		
		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLINFO_HEADER_OUT, true);
		curl_setopt($ch, CURLOPT_ENCODING, "");
		curl_setopt($ch, CURLOPT_TIMEOUT, 120);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_HTTPHEADER, $request_headers);
		$body = curl_exec($ch);
		$json = json_decode($body, true);
		curl_close($ch);
		echo "<pre>";
		print_r($json);
	  }
    }
?>